
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author minhn
 */
public class MyString implements IString{

    @Override
    public int f1(String string) {
        int count=0;
        String txt[]=string.split("\\s+");
        for (String s : txt) {
            int dem=0;
            for (int i = 0; i < s.length(); i++) {
                if(Character.isDigit(s.charAt(i))){
                    dem++;
                }
            }
            if(dem>=3){
                count++;
            }
        }
        return count;
    }

    @Override
    public String f2(String string) {
        int temp=0;
        String result="";
        ArrayList<String> list=new ArrayList();
        String txt[]=string.split("\\s+");
        for (String s : txt) {
            list.add(s);
        }
        Collections.sort(list, new Comparator<String>(){
            @Override
            public int compare(String a, String b){
                return a.compareTo(b);  //neu muon sap xep list giam dan thi doi cho a voi b
            }
        });
//        boolean check=true;
        for (int i = 0; i < list.size(); i++) {
            if(!list.get(i).equals(txt[i])){
                list.remove(i);
                temp=i;
                break;
                
            }
        }
        for (int i = 0; i < temp; i++) {
            result+=txt[i]+" ";
        }
        for(int i=temp+1; i<txt.length; i++){
            result+=txt[i]+" ";
        }
        return result.trim();
    }
    
}
