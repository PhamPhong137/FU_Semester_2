
import java.util.List;

/**
 *
 * @author alias
 */
public class MyPrinter implements IPrinter {
    
    @Override
    public void f1(List<Printer> list, double price) {
//        for (int i = 0; i < list.size(); i++) {
//            //kiem tra gia voi gia da cho
//            if(list.get(i).getPrice()<=price){
//                //xoa
//                list.remove(i);
//                i--;
//            }
//        }
        for (int i = list.size()-1; i >=0 ; i--) {
            if(list.get(i).getPrice()<=price){
                list.remove(i);
            }
        }
    }
    
    @Override
    public int f2(List<Printer> list, String name) {
        int count = 0;
        for (Printer printer : list) {
            if (printer.getName().toLowerCase().contains(name.toLowerCase())) {                
                count++;
            }
        }
        return count;
    }
    
}
