

 
import java.util.*;

public class MyCourse implements ICourse{ 

    @Override
    public void f1(List<Course> a, int st) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int f2(List<Course> a, double fee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


     
    
     
}
