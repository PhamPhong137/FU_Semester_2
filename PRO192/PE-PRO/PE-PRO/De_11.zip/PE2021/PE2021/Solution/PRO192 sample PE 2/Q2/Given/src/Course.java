
public class Course {   
    
    public Course() {
    }

    public Course(String name, double fee) {
        
    }
 
    public String getName() {
       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   

     
}
