
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Vi Tuan Vu
 */
public class MyBeaver implements IBeaver {

    @Override
    public int f1(List<Beaver> list) {
        int count = 0;
        double avg;
        double sum = 0;

        for (Beaver beaver : list) {
            sum += beaver.getWeight();
        }
        avg = sum / list.size();
        for (Beaver beaver : list) {
            if (beaver.getWeight() > avg) {
                count++;
            }
        }
        return count;
    }

    @Override
    public void f2(List<Beaver> list) {
        int maxWeight = list.get(0).getWeight();
        for (Beaver beaver : list) {
            if (beaver.getWeight() > maxWeight) {
                maxWeight = beaver.getWeight();

            }
        }
        //Sau khi tim phan tu dau tien
        //tim phan tu dau tien co weight = maxWeight
        Beaver beaverTmp = new Beaver();
        for (int i = 0; i < list.size(); i++) {
            Beaver beaver = list.get(i);
            if (beaver.getWeight() == maxWeight) {
                beaverTmp = beaver;
                list.remove(i);
                break;
            }
        }

        //insert
        list.add(2, beaverTmp);
    }

    @Override
    public void f3(List<Beaver> list) {
        int start = 2;
        int end = 6;

        for (int i = start; i < end; i++) {
            for (int j = i + 1; j <= end; j++) {
                if (list.get(i).getRiver().compareTo(list.get(j).getRiver()) > 0) {
                    Collections.swap(list, i, j);
                } else if (list.get(i).getRiver().compareTo(list.get(i).getRiver()) == 0) {
                    if (list.get(i).getWeight() < list.get(j).getWeight()) {
                        Collections.swap(list, i, j);
                    }
                }
            }
        }

    }
}
