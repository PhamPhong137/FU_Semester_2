
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vi Tuan Vu
 */
public class MyString implements IString{
    public int countDigit(String s){
        int count =0;
        for (int i = 0; i < s.length(); i++) {
            if(Character.isDigit(s.charAt(i))){
                count++;
            }
        }
        return count;
    }
    @Override
    public int f1(String s) {
        String words[] = s.split("[ ]");
        int count = 0;
        for (String word : words) {
            if(countDigit(word)>=3){
                count++;
            }
        }
        return count;
    }
    public boolean isSorted(String s){
        for (int i = 0; i < s.length()-1; i++) {
            if(s.charAt(i)>s.charAt(i+1)){
                return false;
            }
        }
        return true;
    }
    @Override
    public String f2(String s) {
        String words[] = s.split("[ ]");
        String result = "";
        boolean isRemoved = false;
        for (String word : words) {
            if(!isSorted(word)&&!isRemoved){
                isRemoved = true;
            }else{
                result+=word+" ";
            }
        }
        return result.trim();
        
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        MyString myString = new MyString();
        String rs = myString.f2(s);
        System.out.println("output: "+rs);        
    }
}
