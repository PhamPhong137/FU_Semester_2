/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vi Tuan Vu
 */
public class Beaver {
    public String river;
    public int weight;

    public Beaver() {
    }

    public Beaver(String river, int weight) {
        this.river = river;
        this.weight = weight;
    }

    public String getRiver() {
        return river;
    }

    public void setRiver(String river) {
        this.river = river;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
    
}
