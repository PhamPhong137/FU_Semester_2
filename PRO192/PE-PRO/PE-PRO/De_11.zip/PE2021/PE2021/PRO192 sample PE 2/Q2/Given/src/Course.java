
public class Course {   
    public String name;
    public double fee;
    public Course() {
    }

    public Course(String name, double fee) {
        this.name = name;
        this.fee = fee;
    }
 
    public String getName() {
       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }
   

     
}
