
public class Seller extends Employee {  
    
    public double revenue;
    
   
    public Seller() {
     
    }
    public Seller(String name, double revenue, double salary) {
     super(name,salary);
     this.revenue = revenue;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }
    
    @Override
    public double getSalary() {
        double bonus = 0;
        if(revenue<30000){
            bonus = 0.05*revenue;
        }else{
            bonus = 0.1*revenue;
        }
        return salary+bonus;
    }

    @Override
    public String toString() {
        return name+ "\t"+ salary + "\t"+revenue;
    }
    
    
    

    
}
