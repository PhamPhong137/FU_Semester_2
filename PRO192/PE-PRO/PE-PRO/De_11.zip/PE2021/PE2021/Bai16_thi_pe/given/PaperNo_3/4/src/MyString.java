/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vi Tuan Vu
 */
public class MyString implements IString{

    @Override
    public int f1(String s) {
        int sum = 0;
        for (int i = 0; i < s.length(); i++) {
            if(Character.isDigit(s.charAt(i))){
                int num = Integer.parseInt(s.charAt(i)+"");
                sum += num;
            }
        }
        return sum;
    }

    @Override
    public String f2(String s) {
        String result = "";
        for (int i = 0; i < s.length(); i++) {
            if(!Character.isDigit(s.charAt(i))){
                result =result+s.charAt(i);
            }else{
                int num = Integer.parseInt(s.charAt(i)+"");
                if(num>=0&&num<=8){
                    num=num+1;
                }
                result = result+num;
            }
        }
        return result;
    }
    
}
