
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vi Tuan Vu
 */
public class MyFan implements IFan{

    @Override
    public void f1(List<Fan> list, String xCode) {
        for (Fan fan : list) {
            if(fan.getCode().startsWith(xCode)){
                fan.setPrice(fan.getPrice()*1.1);
            }
        }
    }

    @Override
    public int f2(List<Fan> list, double xPrice) {
        int count = 0;
        for (Fan fan : list) {
            if(fan.getPrice()<=xPrice){
                count++;
            }
        }
        return count;
    }

    @Override
    public void f3(List<Fan> list) {
        Collections.sort(list, new Comparator<Fan>() {
            @Override
            public int compare(Fan o1, Fan o2) {
              if(o1.getPrice()>o2.getPrice()){
                  return 1;
              }else if(o1.getPrice()<o2.getPrice()){
                  return -1;
              }else{
                  //2 gia bang nhau
                  //sap xep tang dan theo code
                  return o1.getCode().compareToIgnoreCase(o2.getCode());
              }
            }
        });
    }
    
}
