/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alias
 */
public class VNMotor extends Motor{
    
    
    public VNMotor(String brandName,String series,double price) {
        
    }

    
    
    public double getSalePrice(){
        return 0;
    }

    
    
    
    
}
