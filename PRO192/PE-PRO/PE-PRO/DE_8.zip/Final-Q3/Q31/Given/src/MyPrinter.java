
import java.util.List;


/**
 *
 * @author alias
 */
public class MyPrinter implements IPrinter{

    @Override
    public void f1(List<Printer> a, double price) {//price = 120
        for (int i = 0; i < a.size(); i++) {
            if(a.get(i).getPrice() <= price){
                a.remove(i);
                i--;
            }
        }
    }
    //co 2 truong hop la nen dung for i
    //1 - xoa phan tu khoi 1 list
    //2 - tim vi tri cua phan tu trong list

    @Override
    public int f2(List<Printer> a, String name) {//Hp
        int count = 0;
        name = name.toLowerCase();
        for (Printer o : a) {
            if(o.getName().toLowerCase().contains(name)){
                count++;
            }
        }
        return count;
    }

    

    
    
}
